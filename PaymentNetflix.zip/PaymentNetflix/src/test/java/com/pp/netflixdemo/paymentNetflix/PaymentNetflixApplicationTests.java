package com.pp.netflixdemo.paymentNetflix;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaymentNetflixApplicationTests {

	@Test
	void contextLoads() {
	}

}
